void main() {
	gl_FragColor.rgba = vec4(0.0, 0.0, 0.0, 1.0);
}

