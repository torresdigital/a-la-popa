
This directory contains placeholder model files only.

Placeholder sound files are suffixed with `.weak` so that files from the non-free
paks take precedence.
